// =============================================================
// NODE 4 – MOTOR CONTROLLER (Webots)
// =============================================================
// Role:
//   - Subscribe to high-level motion commands from other nodes
//     via Webots Receiver (e.g. "FOLLOW_LEFT", "STOP", "SEARCH")
//   - Use LiDAR to maintain a safe distance from obstacles/human
//   - Convert commands + distance into wheel velocities
//
// Other nodes (in your group) are responsible for:
//   - Camera / colour detection (Node 1 & 2)
//   - State machine / decision logic (Node 3)
//   - They send string commands using an Emitter
// =============================================================

#include <webots/robot.h>
#include <webots/motor.h>
#include <webots/lidar.h>
#include <webots/receiver.h>

#include <stdio.h>
#include <string.h>
#include <math.h>

#define TIME_STEP      64
#define BASE_SPEED     2.0
#define TURN_SPEED     1.0
#define SAFE_DISTANCE  1.2   //to maintain safe distance

typedef struct {
  WbDeviceTag leftMotor;
  WbDeviceTag rightMotor;
  WbDeviceTag lidar;
  WbDeviceTag receiver;
} DeviceTags;

// ------------ INITIALISE DEVICES ------------

DeviceTags init_devices() {
  DeviceTags d;

  d.leftMotor  = wb_robot_get_device("left wheel motor");
  d.rightMotor = wb_robot_get_device("right wheel motor");

  wb_motor_set_position(d.leftMotor,  INFINITY);
  wb_motor_set_position(d.rightMotor, INFINITY);

  wb_motor_set_velocity(d.leftMotor,  0.0);
  wb_motor_set_velocity(d.rightMotor, 0.0);

  d.lidar = wb_robot_get_device("LDS-01");
  wb_lidar_enable(d.lidar, TIME_STEP);

  d.receiver = wb_robot_get_device("receiver");
  wb_receiver_enable(d.receiver, TIME_STEP);

  return d;
}

// ------------- LiDAR FRONT DISTANCE (AVERAGE) -------------

double get_front_distance(const DeviceTags *d) {
  const float *ranges = wb_lidar_get_range_image(d->lidar);
  int width = wb_lidar_get_horizontal_resolution(d->lidar);

  double sum = 0.0;
  int count  = 0;

  // Average ~20 central beams
  for (int i = width / 2 - 10; i <= width / 2 + 10; i++) {
    float r = ranges[i];
    if (!isnan(r) && r < 10.0f) {
      sum += r;
      count++;
    }
  }

  if (count == 0)
    return 10.0;   // nothing detected → far away

  return sum / count;
}

// ------------- APPLY COMMAND + SAFETY TO MOTORS -------------

void apply_motion(const DeviceTags *d,
                  const char *command,
                  double front_distance) {

  double leftSpeed  = 0.0;
  double rightSpeed = 0.0;

  // SAFETY OVERRIDE: too close → stop
  if (front_distance < SAFE_DISTANCE && front_distance > 0.3) {
    leftSpeed  = 0.0;
    rightSpeed = 0.0;
    printf("[Node4] EMERGENCY STOP (%.2f m)\n", front_distance);
  } else {

    // FOLLOW behaviours
    if (strcmp(command, "FOLLOW_LEFT") == 0) {
      leftSpeed  = BASE_SPEED - TURN_SPEED;
      rightSpeed = BASE_SPEED + TURN_SPEED;
    }
    else if (strcmp(command, "FOLLOW_RIGHT") == 0) {
      leftSpeed  = BASE_SPEED + TURN_SPEED;
      rightSpeed = BASE_SPEED - TURN_SPEED;
    }
    else if (strcmp(command, "FOLLOW_CENTER") == 0) {
      leftSpeed  = BASE_SPEED;
      rightSpeed = BASE_SPEED;
    }

    // STOP
    else if (strcmp(command, "STOP") == 0) {
      leftSpeed  = 0.0;
      rightSpeed = 0.0;
    }

    // SEARCH: rotate on the spot
    else if (strcmp(command, "SEARCH") == 0) {
      leftSpeed  = 1.0;
      rightSpeed = -1.0;
    }

    // CHARGE: slow forward drive (e.g. towards charger)
    else if (strcmp(command, "CHARGE") == 0) {
      leftSpeed  = 1.0;
      rightSpeed = 1.0;
    }

    // Unknown → stay still (safe default)
    else {
      leftSpeed  = 0.0;
      rightSpeed = 0.0;
    }
  }

  wb_motor_set_velocity(d->leftMotor,  leftSpeed);
  wb_motor_set_velocity(d->rightMotor, rightSpeed);
}

// ------------------------- MAIN LOOP ------------------------

int main() {
  wb_robot_init();

  DeviceTags d = init_devices();
  printf("[Node4] Motor controller started.\n");

  // Default state when no command yet
  char current_command[32] = "STOP";

  while (wb_robot_step(TIME_STEP) != -1) {

    // 1. Read LiDAR safe distance
    double front_dist = get_front_distance(&d);

    // 2. Read latest command from other nodes (Emitter → Receiver)
    while (wb_receiver_get_queue_length(d.receiver) > 0) {

      const char *msg = wb_receiver_get_data(d.receiver);
      // Copy into current_command safely
      snprintf(current_command, sizeof(current_command), "%s", msg);

      printf("[Node4] Received command: %s\n", current_command);

      wb_receiver_next_packet(d.receiver);
    }

    // 3. Apply motion based on command + LiDAR safety
    apply_motion(&d, current_command, front_dist);
  }

  wb_robot_cleanup();
  return 0;
}
